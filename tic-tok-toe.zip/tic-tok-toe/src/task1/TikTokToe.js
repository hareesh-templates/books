export default function TikTokToe() {
  return (
    <>
      <button>X</button>
    </>
  );
}
