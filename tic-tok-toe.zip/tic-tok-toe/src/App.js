import "./App.css";
import Game from "./task1/tic-tok-toe";
import "./task1/styles.css";

function App() {
  return (
    <>
      <Game />
    </>
  );
}

export default App;
